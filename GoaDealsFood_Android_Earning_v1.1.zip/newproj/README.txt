GOA DEALS & FOOD - Android App Project

This Android app opens the live Goa Deals & Food website inside a native Android WebView.
Website: https://white-water-04bf.guruvillastay.workers.dev/

Open this folder in Android Studio and Build > Build APK(s).
The APK will be in app/build/outputs/apk/debug/ after a debug build.

Package: com.goadetailsfood.app
Version: 1.0
