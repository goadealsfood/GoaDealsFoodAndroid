Goa Deals & Food - Android Project

This is the Android Studio project for the Goa Deals & Food app.
Next step: open this project in Android Studio and build the APK.

App purpose:
- Goa Deals & Food
- Hotels & Stay
- Tiffin & Food
- Deals & Offers
- Add Listing
- Earnings section

The app uses the existing live website as its content base.
